package controller;

import model.Sponsor;
import model.Tier;
import model.Event;
import model.Payment;
import service.SponsorService;
import service.TierService;
import service.EventService;
import service.PaymentService;
import exception.SponsorshipException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.util.List;

public class SponsorshipController {

    private final SponsorService sponsorService;
    private final TierService tierService;
    private final EventService eventService;
    private final PaymentService paymentService;
    private final BufferedReader br;

    public SponsorshipController() {
        this.sponsorService = new SponsorService();
        this.tierService = new TierService();
        this.eventService = new EventService();
        this.paymentService = new PaymentService();
        this.br = new BufferedReader(new InputStreamReader(System.in));
    }

    public void displayMenu() {
        System.out.println("---------- Sponsorship Management System ----------");
        System.out.println("1. Register Sponsor");
        System.out.println("2. Assign Tier to Sponsor");
        System.out.println("3. View Sponsorship Details");
        System.out.println("4. Make Payment");
        System.out.println("5. Generate Report");
        System.out.println("0. Exit");
        System.out.println("Enter your choice:");
    }

    public void start() throws IOException, SQLException, SponsorshipException {
        boolean running = true;
        while (running) {
            displayMenu();
            int choice = Integer.parseInt(br.readLine());
            switch (choice) {
                case 1:
                    registerSponsor();
                    break;
                case 2:
                    assignTierToSponsor();
                    break;
                case 3:
                    viewSponsorshipDetails();
                    break;
                case 4:
                    makePayment();
                    break;
                case 5:
                    generateReport();
                    break;
                case 0:
                    running = false;
                    System.out.println("Exiting the application. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice, please try again.");
            }
        }
    }

    public void registerSponsor() throws IOException, SQLException, SponsorshipException {
        System.out.println("Enter Sponsor Name:");
        String name = br.readLine();
        System.out.println("Enter Sponsor Email:");
        String email = br.readLine();
        System.out.println("Enter Sponsor Phone:");
        String phone = br.readLine();
        System.out.println("Enter Event ID:");
        int eventId = Integer.parseInt(br.readLine());
        
        Event event = eventService.getEventById(eventId);
        Sponsor sponsor = new Sponsor(0, name, email, phone, null, event);
        sponsorService.registerSponsor(sponsor);

        System.out.println("Sponsor registered successfully.");
    }

    public void assignTierToSponsor() throws IOException, SQLException, SponsorshipException {
        System.out.println("Enter Sponsor ID:");
        int sponsorId = Integer.parseInt(br.readLine());
        System.out.println("Enter Tier ID (1 for Gold, 2 for Silver, 3 for Bronze):");
        int tierId = Integer.parseInt(br.readLine());

        Tier tier = tierService.getTierById(tierId);
        sponsorService.assignTier(sponsorId, tier);

        System.out.println("Tier assigned successfully to Sponsor.");
    }

    public void viewSponsorshipDetails() throws IOException, SQLException, SponsorshipException {
        System.out.println("Enter Sponsor ID to view details:");
        int sponsorId = Integer.parseInt(br.readLine());

        Sponsor sponsor = sponsorService.getSponsorById(sponsorId);
        System.out.println("Sponsor Details:");
        System.out.println("Name: " + sponsor.getName());
        System.out.println("Email: " + sponsor.getEmail());
        System.out.println("Phone: " + sponsor.getPhone());
        System.out.println("Tier: " + sponsor.getTier().getName());
        System.out.println("Event: " + sponsor.getEvent().getEventName());
    }

    public void makePayment() throws IOException, SQLException, SponsorshipException {
        System.out.println("Enter Sponsor ID to make payment:");
        int sponsorId = Integer.parseInt(br.readLine());
        System.out.println("Enter Payment Amount:");
        double amount = Double.parseDouble(br.readLine());
        System.out.println("Enter Payment Date (YYYY-MM-DD):");
        String paymentDate = br.readLine();

        Sponsor sponsor = sponsorService.getSponsorById(sponsorId);
        Payment payment = new Payment(0, sponsor, amount, paymentDate, false);
        paymentService.processPayment(payment);

        System.out.println("Payment processed successfully.");
    }

    public void generateReport() throws SQLException {
        System.out.println("Generating Sponsorship Report...");

        // Get all sponsors from the SponsorService
        List<Sponsor> sponsors = sponsorService.getAllSponsors();
        if (sponsors.isEmpty()) {
            System.out.println("No sponsors available to generate report.");
            return;
        }

        // Print report header
        System.out.println("Sponsor Report:");
        System.out.println("----------------------------------------------------------");
        System.out.println("Sponsor ID | Sponsor Name | Tier | Event Name | Payment Status");
        System.out.println("----------------------------------------------------------");

        // Loop through sponsors and display their details
        for (Sponsor sponsor : sponsors) {
            // Get the associated tier and event
            String tierName = sponsor.getTier() != null ? sponsor.getTier().getName() : "No Tier Assigned";
            String eventName = sponsor.getEvent() != null ? sponsor.getEvent().getEventName() : "No Event Assigned";
            
            // Check if the sponsor has made any payments and display the payment status
            Payment payment = paymentService.getPaymentBySponsor(sponsor.getSponsorId());
            String paymentStatus = (payment != null && payment.getStatus()) ? "Paid" : "Pending";

            // Print sponsor details
            System.out.println(sponsor.getSponsorId() + " | " + sponsor.getName() + " | " + tierName + " | " + eventName + " | " + paymentStatus);
        }
        System.out.println("----------------------------------------------------------");
    }
}
