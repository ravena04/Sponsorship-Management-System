package service;

import dao.EventDAO;
import dao.EventDAOImpl;
import model.Event;
import exception.SponsorshipException;
import java.sql.SQLException;

public class EventService {
    private final EventDAO eventDAO;

    public EventService() {
        this.eventDAO = new EventDAOImpl();
    }

    // Get event by ID
    public Event getEventById(int eventId) throws SQLException, SponsorshipException {
        Event event = eventDAO.getEventById(eventId);
        if (event == null) {
            throw new SponsorshipException("Event not found.");
        }
        return event;
    }
}
