package service;

import dao.TierDAO;
import dao.TierDAOImpl;
import model.Tier;
import exception.SponsorshipException;
import java.sql.SQLException;

public class TierService {
    private final TierDAO tierDAO;

    public TierService() {
        this.tierDAO = new TierDAOImpl();
    }

    // Get tier by ID
    public Tier getTierById(int tierId) throws SQLException, SponsorshipException {
        Tier tier = tierDAO.getTierById(tierId);
        if (tier == null) {
            throw new SponsorshipException("Tier not found.");
        }
        return tier;
    }
}
