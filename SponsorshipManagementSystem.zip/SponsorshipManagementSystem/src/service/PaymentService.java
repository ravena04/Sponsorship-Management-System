package service;

import dao.PaymentDAO;
import dao.PaymentDAOImpl;
import model.Payment;
import exception.SponsorshipException;
import java.sql.SQLException;

public class PaymentService {
    private final PaymentDAO paymentDAO;

    public PaymentService() {
        this.paymentDAO = new PaymentDAOImpl();
    }

    // Process payment for the sponsor
    public void processPayment(Payment payment) throws SQLException, SponsorshipException {
        if (payment.getAmount() <= 0) {
            throw new SponsorshipException("Payment amount must be positive.");
        }
        paymentDAO.processPayment(payment);
    }

    // Get payment by sponsor ID
    public Payment getPaymentBySponsor(int sponsorId) throws SQLException {
        return paymentDAO.getPaymentBySponsor(sponsorId);
    }
}
