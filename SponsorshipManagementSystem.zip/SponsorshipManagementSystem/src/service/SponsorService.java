package service;

import dao.SponsorDAO;
import dao.SponsorDAOImpl;
import model.Sponsor;
import model.Tier;
import exception.SponsorshipException;
import java.sql.SQLException;
import java.util.List;

public class SponsorService {
    private final SponsorDAO sponsorDAO;

    public SponsorService() {
        this.sponsorDAO = new SponsorDAOImpl();
    }

    // Register a new sponsor
    public void registerSponsor(Sponsor sponsor) throws SQLException, SponsorshipException {
        if (sponsorDAO.getSponsorByEmail(sponsor.getEmail()) != null) {
            throw new SponsorshipException("Sponsor with this email already exists.");
        }
        sponsorDAO.registerSponsor(sponsor);
    }

    // Assign a tier to the sponsor
    public void assignTier(int sponsorId, Tier tier) throws SQLException, SponsorshipException {
        Sponsor sponsor = sponsorDAO.getSponsorById(sponsorId);
        if (sponsor == null) {
            throw new SponsorshipException("Sponsor not found.");
        }
        sponsor.setTier(tier);
        sponsorDAO.updateSponsor(sponsor);
    }

    // Get sponsor details by ID
    public Sponsor getSponsorById(int sponsorId) throws SQLException {
        return sponsorDAO.getSponsorById(sponsorId);
    }

    // Get all sponsors
    public List<Sponsor> getAllSponsors() throws SQLException {
        return sponsorDAO.getAllSponsors();
    }
}
