package exception;

// Custom Exception for Sponsorship Management System
public class SponsorshipException extends Exception {
    public SponsorshipException(String message) {
        super(message);
    }

    public SponsorshipException(String message, Throwable cause) {
        super(message, cause);
    }
}
