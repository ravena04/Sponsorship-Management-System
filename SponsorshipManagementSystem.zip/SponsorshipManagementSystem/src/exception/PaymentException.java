package exception;

// Custom Exception for Payment-related Issues
public class PaymentException extends SponsorshipException {
    public PaymentException(String message) {
        super(message);
    }

    public PaymentException(String message, Throwable cause) {
        super(message, cause);
    }
}
