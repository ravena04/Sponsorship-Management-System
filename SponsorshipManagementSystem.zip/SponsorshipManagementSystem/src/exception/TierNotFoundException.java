package exception;

// Custom Exception when Tier is not found
public class TierNotFoundException extends SponsorshipException {
    public TierNotFoundException(String message) {
        super(message);
    }

    public TierNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }
}
