package exception;

public class InvalidInputException extends SponsorshipException {

    // Constructor with message
    public InvalidInputException(String message) {
        super(message);
    }

    // Constructor with message and cause
    public InvalidInputException(String message, Throwable cause) {
        super(message, cause);
    }
}
