package exception;

// Custom Exception when Sponsor is not found
public class SponsorNotFoundException extends SponsorshipException {
    public SponsorNotFoundException(String message) {
        super(message);
    }

    public SponsorNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }
}
