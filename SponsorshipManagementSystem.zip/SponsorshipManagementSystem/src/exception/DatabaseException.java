package exception;

public class DatabaseException extends SponsorshipException {

    // Constructor with message
    public DatabaseException(String message) {
        super(message);
    }

    // Constructor with message and cause
    public DatabaseException(String message, Throwable cause) {
        super(message, cause);
    }
}
