package model;

public class Tier {
    private int tierId;
    private String tierName;

    // Constructor matching the parameters
    public Tier(int tierId, String tierName) {
        this.tierId = tierId;
        this.tierName = tierName;
    }

    // Getters and setters
    public int getTierId() {
        return tierId;
    }

    public void setTierId(int tierId) {
        this.tierId = tierId;
    }

    public String getName() {
        return tierName;
    }

    public void setName(String tierName) {
        this.tierName = tierName;
    }
}
