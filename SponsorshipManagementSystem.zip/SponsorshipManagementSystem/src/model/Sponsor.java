package model;

public class Sponsor {
    private int sponsorId;
    private String name;
    private String email;
    private String phone;
    private Tier tier;  // Tier assigned to the sponsor
    private Event event;  // Event associated with the sponsor

    // Constructor
    public Sponsor(int sponsorId, String name, String email, String phone, Tier tier, Event event) {
        this.sponsorId = sponsorId;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.tier = tier;
        this.event = event;
    }

    // Getter and Setter methods
    public int getSponsorId() { return sponsorId; }
    public void setSponsorId(int sponsorId) { this.sponsorId = sponsorId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public Tier getTier() { return tier; }
    public void setTier(Tier tier) { this.tier = tier; }

    public Event getEvent() { return event; }
    public void setEvent(Event event) { this.event = event; }
}
