package model;

public class SponsorshipPackage {
    private int packageId;
    private String packageName;
    private String benefits;
    private double cost;

    // Constructor
    public SponsorshipPackage(int packageId, String packageName, String benefits, double cost) {
        this.packageId = packageId;
        this.packageName = packageName;
        this.benefits = benefits;
        this.cost = cost;
    }

    // Getter for packageName
    public String getPackageName() {
        return packageName;
    }

    // Setter for packageName
    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    // Getter for benefits
    public String getBenefits() {
        return benefits;
    }

    // Setter for benefits
    public void setBenefits(String benefits) {
        this.benefits = benefits;
    }

    // Getter for cost
    public double getCost() {
        return cost;
    }

    // Setter for cost
    public void setCost(double cost) {
        this.cost = cost;
    }
}
