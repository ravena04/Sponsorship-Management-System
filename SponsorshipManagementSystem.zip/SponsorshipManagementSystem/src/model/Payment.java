package model;

public class Payment {
    private int paymentId;
    private Sponsor sponsor;  // Sponsor making the payment
    private double amount;
    private String date;  // Payment date
    private boolean status;  // Payment status (paid or pending)

    // Constructor
    public Payment(int paymentId, Sponsor sponsor, double amount, String date, boolean status) {
        this.paymentId = paymentId;
        this.sponsor = sponsor;
        this.amount = amount;
        this.date = date;
        this.status = status;
    }

    // Getter and Setter methods
    public int getPaymentId() { return paymentId; }
    public void setPaymentId(int paymentId) { this.paymentId = paymentId; }

    public Sponsor getSponsor() { return sponsor; }
    public void setSponsor(Sponsor sponsor) { this.sponsor = sponsor; }

    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }

    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }

    public boolean getStatus() { return status; }
    public void setStatus(boolean status) { this.status = status; }
}
