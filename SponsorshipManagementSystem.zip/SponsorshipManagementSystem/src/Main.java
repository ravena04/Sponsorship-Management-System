import java.io.IOException;
import java.sql.SQLException;
import exception.SponsorshipException;
import exception.SponsorNotFoundException;

import controller.SponsorshipController;

public class Main {
    public static void main(String[] args) throws IOException, SQLException, SponsorshipException, SponsorNotFoundException {
        // Create an instance of SponsorshipController to start the application
        SponsorshipController sc = new SponsorshipController();
        
        // Start the Sponsorship Management System logic
        sc.start();
    }
}
