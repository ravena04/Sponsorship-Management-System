package utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseUtility {

    // Database connection details
    private static final String URL = "jdbc:mysql://localhost:3306/SponsorshipManagementSystem";
    private static final String USER = "root";
    private static final String PASSWORD = "Ravena@2005";

    // Method to get database connection
    public static Connection getConnection() {
        try {
            // Load the MySQL JDBC driver (if not loaded by default)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish and return the connection
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException | ClassNotFoundException e) {
            // Print error if connection fails
            e.printStackTrace();
        }
        return null;
    }
}
