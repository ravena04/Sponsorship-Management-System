package dao;

import dao.TierDAO;
import model.Tier;
import utility.DatabaseUtility;
import java.sql.*;

public class TierDAOImpl implements TierDAO {
    private final Connection connection;

    public TierDAOImpl() {
        this.connection = DatabaseUtility.getConnection();  // Get the connection from utility class
    }

    @Override
    public Tier getTierById(int tierId) throws SQLException {
        String query = "SELECT * FROM tier WHERE tier_id = ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, tierId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Tier(
                        rs.getInt("tier_id"),
                        rs.getString("tier_name")
                );
            }
        }
        return null;  // Return null if tier not found
    }
}
