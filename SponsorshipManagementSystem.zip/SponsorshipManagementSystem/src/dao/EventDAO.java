package dao;

import model.Event;
import java.sql.SQLException;

public interface EventDAO {
    Event getEventById(int eventId) throws SQLException;
}
