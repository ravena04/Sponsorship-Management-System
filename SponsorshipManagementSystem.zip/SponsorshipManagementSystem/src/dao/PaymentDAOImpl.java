package dao;

import dao.PaymentDAO;
import model.Payment;
import utility.DatabaseUtility;
import java.sql.*;

public class PaymentDAOImpl implements PaymentDAO {
    private final Connection connection;

    public PaymentDAOImpl() {
        this.connection = DatabaseUtility.getConnection();  // Get the connection from utility class
    }

    @Override
    public void processPayment(Payment payment) throws SQLException {
        String query = "INSERT INTO payment (sponsor_id, amount, payment_date, status) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, payment.getSponsor().getSponsorId());
            ps.setDouble(2, payment.getAmount());
            ps.setString(3, payment.getDate());
            ps.setBoolean(4, payment.getStatus());
            ps.executeUpdate();
        }
    }

    @Override
    public Payment getPaymentBySponsor(int sponsorId) throws SQLException {
        String query = "SELECT * FROM payment WHERE sponsor_id = ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, sponsorId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Payment(
                        rs.getInt("payment_id"),
                        null,  // Sponsor can be populated after getting from DB
                        rs.getDouble("amount"),
                        rs.getString("payment_date"),
                        rs.getBoolean("status")
                );
            }
        }
        return null;
    }
}
