package dao;

import dao.SponsorDAO;
import model.Sponsor;
import model.Event;
import model.Tier;
import utility.DatabaseUtility;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SponsorDAOImpl implements SponsorDAO {
    private final Connection connection;

    public SponsorDAOImpl() {
        this.connection = DatabaseUtility.getConnection();  // Get the connection from utility class
    }

    @Override
    public void registerSponsor(Sponsor sponsor) throws SQLException {
        String query = "INSERT INTO sponsor (sponsor_name, sponsor_email, sponsor_phone, event_id, tier_id) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, sponsor.getName());
            ps.setString(2, sponsor.getEmail());
            ps.setString(3, sponsor.getPhone());
            
            // Check if event is null, set NULL in the query if true
            if (sponsor.getEvent() != null) {
                ps.setInt(4, sponsor.getEvent().getEventId());
            } else {
                ps.setNull(4, Types.INTEGER); // Set NULL for event_id if event is null
            }
            
            // Check if tier is null, set NULL in the query if true
            if (sponsor.getTier() != null) {
                ps.setInt(5, sponsor.getTier().getTierId());
            } else {
                ps.setNull(5, Types.INTEGER); // Set NULL for tier_id if tier is null
            }

            ps.executeUpdate();
        }
    }


    public void updateSponsor(Sponsor sponsor) {
        // Assuming you are getting the event from the sponsor
        if (sponsor.getEvent() != null) {
            // Proceed if the event is not null
            int eventId = sponsor.getEvent().getEventId();
            
            // Your update logic here
            String sql = "UPDATE sponsors SET event_id = ? WHERE sponsor_id = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setInt(1, eventId);  // Set the event_id
                statement.setInt(2, sponsor.getSponsorId()); // Set the sponsor_id
                statement.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            // Handle case when event is null (maybe log the error or provide a default value)
            System.out.println("Event is null for Sponsor with ID: " + sponsor.getSponsorId());
            // Handle accordingly (maybe throw an exception, log, or return)
        }
    }


    public Sponsor getSponsorById(int sponsorId) throws SQLException {
        String query = "SELECT * FROM sponsor WHERE sponsor_id = ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, sponsorId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                // Fetch tier_id from the result set
                int tierId = rs.getInt("tier_id");
                
                // Now, retrieve the Tier object from the database
                Tier tier = getTierById(tierId);
                
                // Create and return the Sponsor object
                return new Sponsor(
                    rs.getInt("sponsor_id"),
                    rs.getString("sponsor_name"),
                    rs.getString("sponsor_email"),
                    rs.getString("sponsor_phone"),
                    tier,  // Set the Tier object
                    null    // You can populate the event later
                );
            }
        }
        return null;  // Return null if sponsor not found
    }

    private Tier getTierById(int tierId) throws SQLException {
        String query = "SELECT * FROM tier WHERE tier_id = ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, tierId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Tier(
                    rs.getInt("tier_id"),
                    rs.getString("tier_name")
                );
            }
        }
        return null;
    }

    @Override
    public Sponsor getSponsorByEmail(String email) throws SQLException {
        String query = "SELECT * FROM sponsor WHERE sponsor_email = ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Sponsor(
                        rs.getInt("sponsor_id"),
                        rs.getString("sponsor_name"),
                        rs.getString("sponsor_email"),
                        rs.getString("sponsor_phone"),
                        null,
                        null
                );
            }
        }
        return null;  // Return null if sponsor not found
    }

    @Override
    public List<Sponsor> getAllSponsors() throws SQLException {
        String query = "SELECT * FROM sponsor";
        List<Sponsor> sponsors = new ArrayList<>();
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                sponsors.add(new Sponsor(
                        rs.getInt("sponsor_id"),
                        rs.getString("sponsor_name"),
                        rs.getString("sponsor_email"),
                        rs.getString("sponsor_phone"),
                        null,  // Populate with Event later
                        null   // Populate with Tier later
                ));
            }
        }
        return sponsors;
    }
}
