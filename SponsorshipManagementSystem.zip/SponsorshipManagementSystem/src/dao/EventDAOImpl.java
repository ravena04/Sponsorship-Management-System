package dao;

import dao.EventDAO;
import model.Event;
import utility.DatabaseUtility;
import java.sql.*;

public class EventDAOImpl implements EventDAO {
    private final Connection connection;

    public EventDAOImpl() {
        this.connection = DatabaseUtility.getConnection();  // Get the connection from utility class
    }

    @Override
    public Event getEventById(int eventId) throws SQLException {
        String query = "SELECT * FROM event WHERE event_id = ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, eventId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Event(
                        rs.getInt("event_id"),
                        rs.getString("event_name"),
                        rs.getString("event_date")
                );
            }
        }
        return null;  // Return null if event not found
    }
}
