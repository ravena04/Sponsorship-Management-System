package dao;

import model.Payment;
import model.Sponsor;
import java.sql.SQLException;

public interface PaymentDAO {
    void processPayment(Payment payment) throws SQLException;
    Payment getPaymentBySponsor(int sponsorId) throws SQLException;
}
