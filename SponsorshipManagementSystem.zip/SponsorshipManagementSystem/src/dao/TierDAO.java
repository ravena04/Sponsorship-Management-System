package dao;

import model.Tier;
import java.sql.SQLException;

public interface TierDAO {
    Tier getTierById(int tierId) throws SQLException;
}
