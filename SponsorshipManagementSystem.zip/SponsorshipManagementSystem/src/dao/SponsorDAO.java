package dao;

import model.Sponsor;
import java.sql.SQLException;
import java.util.List;

public interface SponsorDAO {
    void registerSponsor(Sponsor sponsor) throws SQLException;
    void updateSponsor(Sponsor sponsor) throws SQLException;
    Sponsor getSponsorById(int sponsorId) throws SQLException;
    Sponsor getSponsorByEmail(String email) throws SQLException;
    List<Sponsor> getAllSponsors() throws SQLException;
}
